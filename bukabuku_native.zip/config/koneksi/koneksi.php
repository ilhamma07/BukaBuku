<?php
	$server = "localhost";
	$username = "root";
	$pass = "";
	$db = "bukabuku_perpus";
	$con = mysqli_connect($server,$username,$pass,$db) or die ("Gagal terkoneksi ke database");
?>