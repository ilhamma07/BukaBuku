<nav>
	<div class="home">
    	<h4><a href="index.php"><span class="glyphicon glyphicon-dashboard"></span>Dashboard</a></h4>
    </div>
    <div class="menu-item">
    	<h4><a href="index.php?m=view&p=buku"><span class="glyphicon glyphicon-book"></span>Buku</a></h4>
    </div>
    <div class="menu-item">
    	<h4><a href="index.php?m=view&p=anggota"><span class="glyphicon glyphicon-user"></span>Anggota</a></h4>
    </div>
    <div class="menu-item">
        <h4><a href="index.php?m=view&p=peminjaman"><span class="glyphicon glyphicon-export"></span>Peminjaman</a></h4>
    </div>
    <div class="menu-item">
        <h4><a href="index.php?m=view&p=pengembalian"><span class="glyphicon glyphicon-import"></span>Pengembalian</a></h4>
    </div>
    <div class="menu-item">
    	<h4><a href="index.php?m=../../login&p=logout"><span class="glyphicon glyphicon-log-out"></span>Logout</a></h4>
    </div>
</nav>