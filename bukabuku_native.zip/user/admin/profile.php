<?php
	echo "<span class='glyphicon glyphicon-user'></span>Admin";
?>