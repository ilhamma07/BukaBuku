<ul class="menu">
	<li><a href="index.php">Home</a></li>
	<li><a href="index.php?p=buku">Buku</a></li>
	<li><a href="login/login.php">Login</a></li>
</ul>