<link rel="stylesheet" type="text/css" href="../config/css/login.css">
<link rel="stylesheet" type="text/css" href="../config/css/icon.css">
<form action="cek.php" method="post" class="panel">
	<table class="login">
		<tr>
			<th>
				<h5><span class="glyphicon glyphicon-user"></span>LOGIN</h5>
			</th>
		</tr>
		<tr>
			<td><input type="text" name="user" class="text-login" placeholder="Username" autofocus></td>
		</tr>
		<tr>
			<td><input type="password" name="pass" class="text-login" placeholder="Password"></td>
		</tr>
		<tr>
			<td>
				<input type="submit" value="Login" class="masuk">
				<a href="../index.php"><input type="button" value="Batal" class="batal"></a>
			</td>
		</tr>
	</table>
</form>
<span class="footer">Hak Cipta &copy 2019 | BukaBuku</span>